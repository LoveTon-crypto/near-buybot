"""NEAR data: token metadata (RPC), market data (Intear API, DexScreener fallback), live buys (Intear stream)."""
import asyncio
import base64
import json
import logging
import os
import time

import httpx

log = logging.getLogger("near")

INTEAR = os.environ.get("INTEAR_API", "https://api.intea.rs")
INTEAR_WS = os.environ.get("INTEAR_WS", "wss://api.intea.rs/ws")
DEXS = "https://api.dexscreener.com"
RPC_URLS = ["https://rpc.mainnet.fastnear.com", "https://free.rpc.fastnear.com", "https://rpc.mainnet.near.org"]
TRADE_FIELDS = ["id", "side", "token", "amount", "counterparty", "counterparty_amount", "trader",
                "pool_id", "pool_url", "transaction_id", "usd_value", "timestamp_millis"]
STABLES = {"usdt.tether-token.near", "17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1",
           "a0b86991c6218b36c1d19d4a2e9eb0ce3606eb48.factory.bridge.near",
           "dac17f958d2ee523a2206206994597c13d831ec7.factory.bridge.near"}
DEX_NAMES = {"REF": "Rhea", "VEAX": "Veax", "INTEAR": "Intear DEX", "AIDOLS": "AIdols", "NEARLY": "nearly.trade",
             "JUSTHOOT": "JustHoot", "ORDERLY": "Orderly"}


def f(x) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def table(data) -> list[dict]:
    """Intear answers {result: {columns, rows}} or the inner object; rows are lists in column order."""
    if isinstance(data, dict) and isinstance(data.get("result"), dict):
        data = data["result"]
    if not isinstance(data, dict):
        return []
    cols = data.get("columns") or []
    out = []
    for r in data.get("rows") or []:
        if isinstance(r, dict):
            out.append(r)
        elif isinstance(r, list) and cols:
            out.append(dict(zip(cols, r)))
    return out


def dex_name(pool_id: str) -> str:
    p = (pool_id or "").split("-")[0].upper()
    return DEX_NAMES.get(p, p.title() or "DEX")


def pad_url(token: str) -> str | None:
    if token.endswith(".nearlytrade.near"):
        return f"https://nearly.trade/{token}"
    if token.endswith("launchpad.justhoot.near"):
        return f"https://justhoot.fun/p/{token}"
    return None


class Near:
    def __init__(self):
        self.http = httpx.AsyncClient(timeout=15, headers={"User-Agent": "nd-buybot/1.0"})
        self._info: dict[str, tuple[float, dict]] = {}
        self._near_usd = (0.0, 0.0)

    async def rpc_view(self, account: str, method: str, args: dict | None = None):
        payload = {"jsonrpc": "2.0", "id": "1", "method": "query",
                   "params": {"request_type": "call_function", "finality": "final", "account_id": account,
                              "method_name": method,
                              "args_base64": base64.b64encode(json.dumps(args or {}).encode()).decode()}}
        for url in RPC_URLS:
            try:
                data = (await self.http.post(url, json=payload, timeout=10)).json()
            except (httpx.HTTPError, ValueError):
                continue
            if "result" in data:
                try:
                    return json.loads(bytes(data["result"]["result"]).decode())
                except (KeyError, TypeError, ValueError):
                    return None
            if data.get("error"):
                return None
        return None

    async def metadata(self, token: str) -> dict | None:
        meta = await self.rpc_view(token, "ft_metadata")
        return meta if isinstance(meta, dict) and "decimals" in meta else None

    async def balance(self, account: str, token: str) -> float:
        return f(await self.rpc_view(token, "ft_balance_of", {"account_id": account}))

    async def _intear(self, path: str, params: dict):
        try:
            r = await self.http.get(f"{INTEAR}{path}", params=params)
            return r.json() if r.status_code < 400 else None
        except (httpx.HTTPError, ValueError) as e:
            log.info("intear %s: %s", path, e)
            return None

    async def near_usd(self) -> float:
        if time.time() - self._near_usd[1] < 60 and self._near_usd[0] > 0:
            return self._near_usd[0]
        rows = table(await self._intear("/tokens", {"ids": "wrap.near", "fields": "price_usd"}))
        p = f(rows[0].get("price_usd")) if rows else 0.0
        if p > 0:
            self._near_usd = (p, time.time())
        return p or self._near_usd[0]

    async def info(self, token: str, max_age: float = 15) -> dict:
        """price, mc (fdv), liquidity, holders, symbol, chart url. Cached for a few seconds."""
        hit = self._info.get(token)
        if hit and time.time() - hit[0] < max_age:
            return hit[1]
        d = {"price": 0.0, "mc": 0.0, "liq": 0.0, "holders": 0, "symbol": "", "chart": ""}
        rows = table(await self._intear("/tokens", {
            "ids": token, "fields": "symbol,price_usd,fdv_usd,market_cap_usd,liquidity_usd,holders,main_pool_url"}))
        if rows:
            r = rows[0]
            d.update(price=f(r.get("price_usd")), mc=f(r.get("fdv_usd")) or f(r.get("market_cap_usd")),
                     liq=f(r.get("liquidity_usd")), holders=int(f(r.get("holders"))),
                     symbol=str(r.get("symbol") or ""), chart=str(r.get("main_pool_url") or ""))
        if d["price"] <= 0 or d["liq"] <= 0:  # memepad / fresh tokens: try DexScreener
            try:
                pairs = (await self.http.get(f"{DEXS}/tokens/v1/near/{token}")).json()
            except (httpx.HTTPError, ValueError):
                pairs = []
            if isinstance(pairs, list) and pairs:
                p = max(pairs, key=lambda x: f((x.get("liquidity") or {}).get("usd")))
                d["price"] = d["price"] or f(p.get("priceUsd"))
                d["mc"] = d["mc"] or f(p.get("fdv")) or f(p.get("marketCap"))
                d["liq"] = d["liq"] or f((p.get("liquidity") or {}).get("usd"))
                d["chart"] = p.get("url") or d["chart"]
        d["chart"] = f"https://dexscreener.com/near/{token}" if not d["chart"] else d["chart"]
        self._info[token] = (time.time(), d)
        return d


class BuyFeed:
    """One Intear websocket, one `trades.subscribe` covering every tracked token (side=buy).
    Reconnects forever; resubscribes when the token list changes; resumes with after_id."""

    def __init__(self, tokens_fn, on_buys):
        self.tokens_fn = tokens_fn          # () -> set[str]
        self.on_buys = on_buys              # async (list[dict]) -> None
        self.changed = asyncio.Event()
        self.last_id = None
        self.state = "starting"
        self.last_msg = 0.0
        self.pushed = 0

    def refresh(self):
        self.changed.set()

    async def run(self):
        import websockets
        while True:
            tokens = sorted(self.tokens_fn())[:100]
            if not tokens:
                self.state = "idle (no tokens configured)"
                self.changed.clear()
                await self.changed.wait()
                continue
            self.changed.clear()
            try:
                async with websockets.connect(INTEAR_WS, ping_interval=20, ping_timeout=20,
                                              max_size=16 * 1024 * 1024, open_timeout=15) as ws:
                    params = {"fields": TRADE_FIELDS, "token": tokens, "side": "buy"}
                    if self.last_id is not None:
                        params["after_id"] = self.last_id
                    await ws.send(json.dumps({"id": 1, "method": "trades.subscribe", "params": params}))
                    cols: list = TRADE_FIELDS
                    self.state = f"connected, {len(tokens)} token(s)"
                    log.info("Intear: subscribed to buys of %s", tokens)
                    while not self.changed.is_set():
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=5)
                        except asyncio.TimeoutError:
                            if time.time() - self.last_msg > 90:
                                raise ConnectionError("no data for 90 s")
                            continue
                        self.last_msg = time.time()
                        try:
                            msg = json.loads(raw)
                        except ValueError:
                            continue
                        if msg.get("error"):
                            err = str(msg["error"])
                            log.warning("Intear error: %s", err[:300])
                            self.state = f"error: {err[:100]}"
                            if "too_far_behind" in err:
                                self.last_id = None
                            raise ConnectionError(err[:100])
                        body = msg.get("result") if isinstance(msg.get("result"), dict) else msg
                        cols = body.get("columns") or cols
                        rows = [dict(zip(cols, r)) if isinstance(r, list) else r for r in body.get("rows") or []]
                        if isinstance(body.get("latest_id"), int) and self.last_id is None:
                            self.last_id = body["latest_id"]
                        fresh = []
                        for r in rows:
                            if isinstance(r, dict) and isinstance(r.get("id"), int):
                                self.last_id = max(self.last_id or 0, r["id"])
                                # catch-up rows after a reconnect: only post the last 5 minutes
                                if time.time() * 1000 - f(r.get("timestamp_millis")) < 300_000:
                                    fresh.append(r)
                        if fresh:
                            self.pushed += len(fresh)
                            asyncio.create_task(self.on_buys(fresh))
            except asyncio.CancelledError:
                raise
            except Exception as ex:
                self.state = f"reconnecting ({type(ex).__name__}: {str(ex)[:80]})"
                log.info("Intear: %s", self.state)
                await asyncio.sleep(3)
