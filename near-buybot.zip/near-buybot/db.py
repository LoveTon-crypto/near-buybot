"""SQLite storage: one row per group (one tracked token per group)."""
import json
import sqlite3

DEFAULTS = {"token": "", "symbol": "", "decimals": 0, "emojis": "[]", "media_type": "", "media_id": "",
            "chat_link": "", "min_usd": 0.0, "step_usd": 5.0, "max_emojis": 30, "active": 0}


class DB:
    def __init__(self, path: str):
        self.c = sqlite3.connect(path, check_same_thread=False)
        self.c.row_factory = sqlite3.Row
        self.c.executescript("""
        CREATE TABLE IF NOT EXISTS groups(
            chat_id INTEGER PRIMARY KEY, title TEXT, owner_id INTEGER,
            token TEXT DEFAULT '', symbol TEXT DEFAULT '', decimals INTEGER DEFAULT 0,
            emojis TEXT DEFAULT '[]', media_type TEXT DEFAULT '', media_id TEXT DEFAULT '',
            chat_link TEXT DEFAULT '', min_usd REAL DEFAULT 0, step_usd REAL DEFAULT 5,
            max_emojis INTEGER DEFAULT 30, active INTEGER DEFAULT 0, posted INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS pending(user_id INTEGER PRIMARY KEY, chat_id INTEGER, step TEXT);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
        """)
        cols = {r[1] for r in self.c.execute("PRAGMA table_info(groups)")}
        if "icons" not in cols:  # added later: premium icons for the post lines
            self.c.execute("ALTER TABLE groups ADD COLUMN icons TEXT DEFAULT '{}'")
        self.c.commit()

    def group(self, chat_id: int) -> dict | None:
        r = self.c.execute("SELECT * FROM groups WHERE chat_id=?", (chat_id,)).fetchone()
        if not r:
            return None
        g = dict(r)
        g["emojis"] = json.loads(g["emojis"] or "[]")
        g["icons"] = json.loads(g.get("icons") or "{}")
        return g

    def ensure(self, chat_id: int, title: str, owner_id: int):
        self.c.execute("INSERT INTO groups(chat_id, title, owner_id) VALUES(?,?,?) "
                       "ON CONFLICT(chat_id) DO UPDATE SET title=excluded.title", (chat_id, title, owner_id))
        self.c.commit()

    def set(self, chat_id: int, **kw):
        for k in ("emojis", "icons"):
            if k in kw:
                kw[k] = json.dumps(kw[k], ensure_ascii=False)
        cols = ", ".join(f"{k}=?" for k in kw)
        self.c.execute(f"UPDATE groups SET {cols} WHERE chat_id=?", (*kw.values(), chat_id))
        self.c.commit()

    def delete(self, chat_id: int):
        self.c.execute("DELETE FROM groups WHERE chat_id=?", (chat_id,))
        self.c.commit()

    def active(self) -> list[dict]:
        return [self.group(r[0]) for r in
                self.c.execute("SELECT chat_id FROM groups WHERE active=1 AND token!=''").fetchall()]

    def by_owner(self, user_id: int) -> list[dict]:
        return [dict(r) for r in self.c.execute(
            "SELECT chat_id, title, symbol, active FROM groups WHERE owner_id=?", (user_id,)).fetchall()]

    def all(self) -> list[dict]:
        return [dict(r) for r in self.c.execute(
            "SELECT chat_id, title, symbol, token, active, posted FROM groups").fetchall()]

    def get_setting(self, key: str, default=None):
        r = self.c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return json.loads(r[0]) if r else default

    def put_setting(self, key: str, value):
        self.c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (key, json.dumps(value, ensure_ascii=False)))
        self.c.commit()

    def bump(self, chat_id: int):
        self.c.execute("UPDATE groups SET posted=posted+1 WHERE chat_id=?", (chat_id,))
        self.c.commit()

    def set_pending(self, user_id: int, chat_id: int | None, step: str | None):
        if step is None:
            self.c.execute("DELETE FROM pending WHERE user_id=?", (user_id,))
        else:
            self.c.execute("INSERT OR REPLACE INTO pending VALUES(?,?,?)", (user_id, chat_id, step))
        self.c.commit()

    def pending(self, user_id: int) -> tuple[int, str] | None:
        r = self.c.execute("SELECT chat_id, step FROM pending WHERE user_id=?", (user_id,)).fetchone()
        return (r[0], r[1]) if r else None
