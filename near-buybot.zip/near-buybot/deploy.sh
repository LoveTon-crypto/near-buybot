#!/bin/bash
# Installs/updates the bot on the server. Run from /root/near-buybot.
set -e
cd /root/near-buybot
if [ ! -x venv/bin/python ]; then
  echo ">>> Creating Python environment..."
  apt-get install -y -qq python3-venv >/dev/null 2>&1 || true
  python3 -m venv venv
fi
echo ">>> Installing libraries..."
venv/bin/pip install -q --upgrade pip
venv/bin/pip install -q -r requirements.txt
cp near-buybot.service /etc/systemd/system/near-buybot.service
systemctl daemon-reload
systemctl enable -q near-buybot
cat > /usr/local/bin/buybot-update <<'UPD'
#!/bin/bash
# Download the latest version from GitHub and restart the bot
set -e
cd /root/near-buybot
git fetch -q origin main
git reset -q --hard origin/main
# Repo may hold zips uploaded from the phone (iPhone renames them: bot1.zip, bot2.zip...)
# — unpack the most recently committed one over the folder
ZIP=$(for z in *.zip; do [ -f "$z" ] && echo "$(git log -1 --format=%ct -- "$z") $z"; done | sort -n | tail -1 | cut -d' ' -f2-)
if [ -n "$ZIP" ]; then
  echo ">>> Unpacking $ZIP"
  rm -rf /tmp/nbb && python3 -m zipfile -e "$ZIP" /tmp/nbb
  SRC=/tmp/nbb; [ -d /tmp/nbb/near-buybot ] && SRC=/tmp/nbb/near-buybot
  cp -a "$SRC"/. . && rm -rf /tmp/nbb
fi
exec bash deploy.sh
UPD
chmod +x /usr/local/bin/buybot-update
echo ">>> Restarting the bot..."
systemctl restart near-buybot
sleep 8
if systemctl is-active --quiet near-buybot; then
  echo "✅ Bot is running. Version: $(git log -1 --format='%h — %s' 2>/dev/null)"
else
  echo "❌ Bot didn't start, last log lines:"
  journalctl -u near-buybot -n 25 --no-pager -o cat
fi
