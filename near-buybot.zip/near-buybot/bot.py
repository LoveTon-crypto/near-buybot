"""ND Buybot — posts every buy of a NEAR token into a Telegram group.

Setup: add the bot to the group (as admin) → /setup in the group → configure in DM:
token contract, premium emojis, media (GIF / video / photo), token chat link, min buy, $ per emoji.
Under each post: quick-buy buttons for Bettear (with referral) and NDbot.
"""
import asyncio
import html
import logging
import os
import re
import time

from dotenv import load_dotenv
from telegram import (InlineKeyboardButton, InlineKeyboardMarkup, LinkPreviewOptions, MessageEntity, Update)
from telegram.constants import ChatMemberStatus, ChatType, ParseMode
from telegram.error import BadRequest, Forbidden, RetryAfter
from telegram.ext import (Application, CallbackQueryHandler, ChatMemberHandler, CommandHandler, ContextTypes,
                          MessageHandler, filters)

from db import DB
from near import STABLES, BuyFeed, Near, f, pad_url

load_dotenv()
logging.basicConfig(format="%(asctime)s %(name)s %(levelname)s %(message)s", level=logging.INFO)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("buybot")

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_IDS = {int(x) for x in re.findall(r"\d+", os.environ.get("ADMIN_IDS", ""))}
BETTEAR_BOT = os.environ.get("BETTEAR_BOT", "bettearbot").lstrip("@")
BETTEAR_REF = os.environ.get("BETTEAR_REF", "ref-1094156325")
NDBOT_BOT = os.environ.get("NDBOT_BOT", "ndegen_bot").lstrip("@")
DEFAULT_EMOJI = [["🟢", None]]
START_OK = re.compile(r"^[A-Za-z0-9_=-]{1,64}$")
NO_PREVIEW = LinkPreviewOptions(is_disabled=True)
SUB = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")

db = DB(os.environ.get("DB_PATH", "buybot.db"))
near = Near()
feed: BuyFeed | None = None
_admin_cache: dict[tuple[int, int], tuple[float, bool]] = {}
_locks: dict[int, asyncio.Lock] = {}
_no_custom: set[int] = set()  # groups where Telegram refused custom emoji → plain fallback
_seen: dict[str, float] = {}


# ---------------- links ----------------
def bettear_link(token: str) -> str:
    param = f"{BETTEAR_REF}-buy-{token.replace('.', '=')}"
    return f"https://t.me/{BETTEAR_BOT}?start={param if START_OK.match(param) else BETTEAR_REF}"


def ndbot_link(token: str) -> str:
    param = "c" + token.replace(".", "=")
    return f"https://t.me/{NDBOT_BOT}?start={param}" if START_OK.match(param) else f"https://t.me/{NDBOT_BOT}"


# ---------------- formatting ----------------
def price_fmt(p: float) -> str:
    if p <= 0:
        return "$0"
    if p >= 1:
        return f"${p:,.4f}"
    s = f"{p:.20f}".split(".")[1]
    z = len(s) - len(s.lstrip("0"))
    digits = s[z:z + 4].rstrip("0") or "0"
    return f"$0.0{str(z).translate(SUB)}{digits}" if z >= 4 else f"$0.{'0' * z}{digits}"


def money(x: float) -> str:
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if x >= div:
            return f"${x / div:.2f}".rstrip("0").rstrip(".") + suf
    return f"${x:,.2f}"


def num(x: float) -> str:
    if x >= 100:
        return f"{x:,.0f}"
    return f"{x:,.2f}" if x >= 1 else f"{x:.4g}"


def short(acc: str) -> str:
    return f"{acc[:4]}…{acc[-4:]}" if len(acc) > 24 else acc


# icons in the post — each can be replaced with a premium (animated) emoji in ⚙️ → 🎨 Icons
ICONS = [("paid", "💎", "paid"), ("amount", "🪙", "tokens bought"),
         ("price", "💲", "price"), ("mc", "📊", "MC"), ("holders", "👥", "holders"),
         ("shrimp", "🦐", "buyer < $50"), ("fish", "🐟", "buyer < $250"), ("dolphin", "🐬", "buyer < $1K"),
         ("whale", "🐳", "buyer $1K+"), ("new", "🆕", "new holder")]
ICON_DEFAULT = {k: ch for k, ch, _ in ICONS}


def icon(g: dict, key: str, custom: bool) -> str:
    """Group's own icon → your global default (/defaults) → plain emoji."""
    ch, cid = ((g.get("icons") or {}).get(key) or (db.get_setting("icons", {}) or {}).get(key)
               or [ICON_DEFAULT[key], None])
    return f'<tg-emoji emoji-id="{cid}">{html.escape(ch)}</tg-emoji>' if cid and custom else html.escape(ch)


def fish(usd: float) -> str:
    return "shrimp" if usd < 50 else "fish" if usd < 250 else "dolphin" if usd < 1000 else "whale"


def emoji_row(g: dict, usd: float, custom: bool) -> str:
    ems = g["emojis"] or db.get_setting("emojis") or DEFAULT_EMOJI
    step = g["step_usd"] if g["step_usd"] > 0 else 5
    n = max(1, min(int(g["max_emojis"] or 30), int(usd // step) + 1))
    out = []
    for i in range(n):
        ch, cid = ems[i % len(ems)]
        out.append(f'<tg-emoji emoji-id="{cid}">{html.escape(ch)}</tg-emoji>' if cid and custom else html.escape(ch))
    return "".join(out)


def build_post(g: dict, b: dict, info: dict, near_usd: float, custom: bool) -> tuple[str, InlineKeyboardMarkup]:
    sym = html.escape(g["symbol"] or info.get("symbol") or "TOKEN")
    amount = b["amount"] / 10 ** int(g["decimals"] or 0)
    cp, cpa = b["counterparty"], b["counterparty_amount"]
    usd = b["usd"]
    if cp == "wrap.near":
        paid = f"{num(cpa / 1e24)} NEAR"
        usd = usd or cpa / 1e24 * near_usd
    elif cp in STABLES:
        paid = f"{num(cpa / 1e6)} USD"
        usd = usd or cpa / 1e6
    else:
        paid = ""
    trader = b["trader"]
    I = lambda k: icon(g, k, custom)
    # ticker → token chat (if set)
    tick = f'<a href="{html.escape(g["chat_link"])}">{sym}</a>' if g["chat_link"] else sym
    lines = [f"<b>{tick} BUY</b>", "",
             emoji_row(g, usd, custom), ""]
    lines.append(f"{I('paid')} <b>{paid}</b> ({money(usd)})" if paid else f"{I('paid')} <b>{money(usd)}</b>")
    lines.append(f"{I('amount')} <b>{num(amount)} {tick}</b>")
    lines.append("")
    lines.append(f"{I('price')} Price: <b>{price_fmt(info['price'])}</b>")
    lines.append(f"{I('mc')} MC: <b>{money(info['mc'])}</b>")
    if info.get("holders"):
        lines.append(f"{I('holders')} Holders: <b>{info['holders']:,}</b>")
    who = f'{I(fish(usd))} <a href="https://nearblocks.io/address/{trader}">{html.escape(short(trader))}</a>'
    if b.get("new_holder"):
        who += f" | {I('new')} <b>New holder!</b>"
    lines.append(who)
    links = [f'<a href="{info["chart"]}">Chart</a>']
    if b.get("tx"):
        links.append(f'<a href="https://nearblocks.io/txns/{b["tx"]}">TX</a>')
    pad = pad_url(g["token"])
    if pad:
        links.append(f'<a href="{pad}">Memepad</a>')
    lines += ["", " | ".join(links), "", f"<code>{html.escape(g['token'])}</code>"]
    rows = [[InlineKeyboardButton("🟢 Bettear", url=bettear_link(g["token"])),
             InlineKeyboardButton("⚡ NDbot", url=ndbot_link(g["token"]))]]
    return "\n".join(lines), InlineKeyboardMarkup(rows)


# ---------------- posting ----------------
async def send_post(bot, g: dict, b: dict):
    info = await near.info(g["token"], max_age=5)
    nu = await near.near_usd()
    chat = g["chat_id"]
    lock = _locks.setdefault(chat, asyncio.Lock())
    async with lock:
        for attempt in range(3):
            custom = chat not in _no_custom
            text, kb = build_post(g, b, info, nu, custom)
            try:
                kw = dict(chat_id=chat, caption=text, parse_mode=ParseMode.HTML, reply_markup=kb)
                if g["media_type"] == "photo":
                    await bot.send_photo(photo=g["media_id"], **kw)
                elif g["media_type"] == "animation":
                    await bot.send_animation(animation=g["media_id"], **kw)
                elif g["media_type"] == "video":
                    await bot.send_video(video=g["media_id"], **kw)
                else:
                    await bot.send_message(chat, text, parse_mode=ParseMode.HTML, reply_markup=kb,
                                           link_preview_options=NO_PREVIEW)
                db.bump(chat)
                break
            except RetryAfter as e:
                await asyncio.sleep(float(e.retry_after) + 0.5)
            except BadRequest as e:
                msg = str(e).lower()
                if custom and ("emoji" in msg or "entit" in msg):
                    _no_custom.add(chat)  # bot can't send premium emoji here → plain emojis
                    log.warning("custom emoji refused in %s: %s", chat, e)
                    continue
                if g["media_type"] and ("file" in msg or "media" in msg or "wrong" in msg):
                    g = dict(g, media_type="")  # media broken → text post
                    continue
                log.warning("post %s: %s", chat, e)
                break
            except Forbidden:
                log.info("kicked from %s → paused", chat)
                db.set(chat, active=0)
                refresh_feed()
                break
        await asyncio.sleep(1.2)  # Telegram: ~20 messages/min per group


async def on_buys(rows: list[dict]):
    """Rows of one block → merge multi-hop pieces of one swap → post to every group tracking the token."""
    merged: dict[tuple, dict] = {}
    for r in rows:
        if str(r.get("side")) != "buy":
            continue
        key = (r.get("transaction_id"), r.get("token"), r.get("trader"))
        m = merged.setdefault(key, {"token": r.get("token"), "trader": r.get("trader") or "", "amount": 0.0,
                                    "counterparty": r.get("counterparty"), "counterparty_amount": 0.0,
                                    "usd": 0.0, "pool_id": r.get("pool_id") or "", "tx": r.get("transaction_id")})
        m["amount"] += f(r.get("amount"))
        if r.get("counterparty") == m["counterparty"]:
            m["counterparty_amount"] += f(r.get("counterparty_amount"))
        m["usd"] += f(r.get("usd_value"))
    now = time.time()
    for k in [k for k, t in _seen.items() if now - t > 600]:
        _seen.pop(k, None)
    groups = db.active()
    for key, b in merged.items():
        sk = f"{key[0]}:{key[1]}:{key[2]}"
        if sk in _seen:
            continue
        _seen[sk] = now
        targets = [g for g in groups if g["token"] == b["token"]]
        if not targets:
            continue
        try:  # balance after the buy ≈ amount bought → first buy of this wallet
            bal = await near.balance(b["trader"], b["token"])
            b["new_holder"] = 0 < bal <= b["amount"] * 1.02
        except Exception:
            b["new_holder"] = False
        if not b["usd"]:
            b["usd"] = 0.0
            if b["counterparty"] == "wrap.near":
                b["usd"] = b["counterparty_amount"] / 1e24 * await near.near_usd()
        for g in targets:
            if b["usd"] >= (g["min_usd"] or 0):
                asyncio.create_task(send_post(bot_ref["bot"], g, b))


bot_ref: dict = {}


def refresh_feed():
    if feed:
        feed.refresh()


# ---------------- admin checks ----------------
async def is_admin(bot, chat_id: int, user_id: int) -> bool:
    if user_id in ADMIN_IDS:
        return True
    hit = _admin_cache.get((chat_id, user_id))
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    try:
        m = await bot.get_chat_member(chat_id, user_id)
        ok = m.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER)
    except Exception:
        ok = False
    _admin_cache[(chat_id, user_id)] = (time.time(), ok)
    return ok


# ---------------- group side ----------------
async def group_setup(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    chat, user = update.effective_chat, update.effective_user
    if not user or not await is_admin(ctx.bot, chat.id, user.id):
        return await update.effective_message.reply_text("Only group admins can set up the buybot.")
    db.ensure(chat.id, chat.title or str(chat.id), user.id)
    me = await ctx.bot.get_me()
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("⚙️ Configure in DM",
                                                     url=f"https://t.me/{me.username}?start=cfg_{chat.id}")]])
    await update.effective_message.reply_text(
        "🤖 <b>ND Buybot</b>\nTap the button to set the token, emojis and media.\n"
        "<i>Make me an admin here so I can post.</i>", parse_mode=ParseMode.HTML, reply_markup=kb)


async def member_update(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    st = update.my_chat_member.new_chat_member.status
    if st in (ChatMemberStatus.LEFT, ChatMemberStatus.BANNED):
        if db.group(update.my_chat_member.chat.id):
            db.set(update.my_chat_member.chat.id, active=0)
            refresh_feed()


# ---------------- DM settings ----------------
def menu_text(g: dict, custom: bool = True) -> str:
    ems = g["emojis"] or db.get_setting("emojis") or DEFAULT_EMOJI
    em = "".join(f'<tg-emoji emoji-id="{c}">{html.escape(e)}</tg-emoji>' if c and custom else html.escape(e)
                 for e, c in ems)
    media = {"photo": "🖼 photo", "animation": "🎞 GIF", "video": "🎬 video"}.get(g["media_type"], "— none")
    tok = f"<code>{html.escape(g['token'])}</code> (${html.escape(g['symbol'])})" if g["token"] else "— not set"
    return (f"⚙️ <b>{html.escape(g['title'] or str(g['chat_id']))}</b>\n\n"
            f"🪙 Token: {tok}\n"
            f"😀 Emojis: {em}\n"
            f"🎨 Icons: {''.join(icon(g, k, custom) for k, _, _ in ICONS)}\n"
            f"🖼 Media: {media}\n"
            f"💬 Chat link: {html.escape(g['chat_link']) or '— none'}\n"
            f"💵 Min buy: <b>${g['min_usd']:g}</b>\n"
            f"📏 1 emoji per <b>${g['step_usd']:g}</b> (max {g['max_emojis']})\n\n"
            f"Status: {'🟢 <b>ON</b>' if g['active'] else '⏸ <b>paused</b>'} · posts sent: {g['posted']}")


def menu_kb(g: dict) -> InlineKeyboardMarkup:
    c = g["chat_id"]
    b = lambda t, a: InlineKeyboardButton(t, callback_data=f"m:{c}:{a}")
    rows = [[b("🪙 Token", "tok"), b("😀 Emojis", "emo")],
            [b("🎨 Icons", "ico"), b("🖼 Media", "med")],
            [b("💬 Chat link", "lnk")],
            [b("💵 Min buy", "min"), b("📏 $ per emoji", "step"), b("🔢 Max", "max")],
            [b("⏸ Pause" if g["active"] else "▶️ Start", "on"), b("🧪 Test post", "test")]]
    extra = []
    if g["media_type"]:
        extra.append(b("🗑 Remove media", "medx"))
    if g["chat_link"]:
        extra.append(b("🗑 Remove link", "lnkx"))
    if g.get("icons"):
        extra.append(b("♻️ Default icons", "icox"))
    if extra:
        rows.append(extra)
    rows.append([b("❌ Delete group", "del"), b("🔄", "show")])
    return InlineKeyboardMarkup(rows)


PROMPTS = {
    "tok": "🪙 Send the token contract, e.g. <code>neo.nearlytrade.near</code>",
    "emo": "😀 Send the emojis for the buy row — premium emojis work. Several = they alternate.\n"
           "Plain emojis: separate them with spaces.",
    "ico": "🎨 Send premium emojis for the post icons, <b>in this order</b> (one per icon; put spaces between plain emojis):\n"
           + "\n".join(f"{i + 1}. {ch} {html.escape(d)}" for i, (_, ch, d) in enumerate(ICONS))
           + "\n\nSend fewer to change only the first ones; a plain emoji keeps that slot plain.",
    "med": "🖼 Send a GIF, video or photo to show with every buy.",
    "lnk": "💬 Send the token chat link (https://t.me/... or @username).",
    "min": "💵 Minimum buy in USD to post (0 = every buy).",
    "step": "📏 How many USD per emoji (e.g. 5 → a $27 buy shows 6 emojis).",
    "max": "🔢 Maximum number of emojis in a row (1–60).",
}


async def show_menu(target, g: dict, edit: bool = False):
    kw = dict(parse_mode=ParseMode.HTML, reply_markup=menu_kb(g), link_preview_options=NO_PREVIEW)
    try:
        if edit:
            await target.edit_message_text(menu_text(g), **kw)
        else:
            await target.reply_text(menu_text(g), **kw)
    except BadRequest as e:
        if "not modified" in str(e).lower():
            return
        # premium emoji in the preview refused → show without them
        if edit:
            await target.edit_message_text(menu_text(g, custom=False), **kw)
        else:
            await target.reply_text(menu_text(g, custom=False), **kw)


async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type != ChatType.PRIVATE:
        return await group_setup(update, ctx)
    user = update.effective_user
    arg = ctx.args[0] if ctx.args else ""
    if arg.startswith("cfg_"):
        try:
            chat_id = int(arg[4:])
        except ValueError:
            chat_id = 0
        g = db.group(chat_id)
        if not g or not await is_admin(ctx.bot, chat_id, user.id):
            return await update.message.reply_text("You're not an admin of that group.")
        if g["owner_id"] != user.id:
            db.set(chat_id, owner_id=user.id)
        db.set_pending(user.id, None, None)
        return await show_menu(update.message, db.group(chat_id))
    me = await ctx.bot.get_me()
    rows = [[InlineKeyboardButton("➕ Add to a group", url=f"https://t.me/{me.username}?startgroup=setup")]]
    for g in db.by_owner(user.id):
        rows.append([InlineKeyboardButton(f"{'🟢' if g['active'] else '⏸'} {g['title']} {g['symbol'] or ''}",
                                          callback_data=f"m:{g['chat_id']}:show")])
    await update.message.reply_text(
        "🤖 <b>ND Buybot</b> — every buy of your NEAR token, live in your group.\n\n"
        "1. Add me to the group and make me admin\n2. Type /setup there\n3. Set token, emojis and media here",
        parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(rows))


async def on_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    _, chat_s, act = q.data.split(":", 2)
    chat_id, user = int(chat_s), q.from_user
    g = db.group(chat_id)
    if not g or not await is_admin(ctx.bot, chat_id, user.id):
        return await q.answer("Not an admin of that group", show_alert=True)
    await q.answer()
    if act == "show":
        db.set_pending(user.id, None, None)
        return await show_menu(q, g, edit=True)
    if act in PROMPTS:
        db.set_pending(user.id, chat_id, act)
        return await q.message.reply_text(PROMPTS[act] + "\n\n/cancel to stop", parse_mode=ParseMode.HTML)
    if act == "on":
        if not g["token"]:
            return await q.message.reply_text("Set the token first.")
        db.set(chat_id, active=0 if g["active"] else 1)
        refresh_feed()
    elif act == "medx":
        db.set(chat_id, media_type="", media_id="")
    elif act == "icox":
        db.set(chat_id, icons={})
    elif act == "lnkx":
        db.set(chat_id, chat_link="")
    elif act == "test":
        if not g["token"]:
            return await q.message.reply_text("Set the token first.")
        info = await near.info(g["token"], max_age=0)
        nu = await near.near_usd() or 2.0
        amt = (25 / info["price"] if info["price"] > 0 else 1_000_000) * 10 ** int(g["decimals"] or 0)
        fake = {"token": g["token"], "trader": "test-buyer.near", "amount": amt, "counterparty": "wrap.near",
                "counterparty_amount": 25 / nu * 1e24, "usd": 25.0, "pool_id": "REF-0", "tx": "",
                "new_holder": True}
        await send_post(ctx.bot, g, fake)
        return await q.message.reply_text("🧪 Test post sent to the group.")
    elif act == "del":
        db.delete(chat_id)
        refresh_feed()
        return await q.edit_message_text("Group removed.")
    await show_menu(q, db.group(chat_id), edit=True)


async def cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    p = db.pending(update.effective_user.id)
    db.set_pending(update.effective_user.id, None, None)
    if p and db.group(p[0]):
        await show_menu(update.message, db.group(p[0]))


def parse_emojis(msg) -> list:
    text = msg.text or msg.caption or ""
    ents = msg.parse_entities([MessageEntity.CUSTOM_EMOJI]) if msg.text else \
        msg.parse_caption_entities([MessageEntity.CUSTOM_EMOJI])
    found = sorted(((e.offset, [t, e.custom_emoji_id]) for e, t in ents.items()), key=lambda x: x[0])
    rest = text
    for _, (t, _) in found:
        rest = rest.replace(t, " ", 1)
    out = [v for _, v in found]
    out += [[p, None] for p in rest.split() if p]
    return out[:20]


async def on_private(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user, msg = update.effective_user, update.message
    p = db.pending(user.id)
    if not p:
        return await msg.reply_text("Use /start to open your groups.")
    chat_id, step = p
    if step in DEFAULT_STEPS and user.id in ADMIN_IDS:
        ems = parse_emojis(msg)
        if not ems:
            return await msg.reply_text("Send at least one emoji.")
        if step == "demo":
            db.put_setting("emojis", ems)
        else:
            cur = dict(db.get_setting("icons", {}) or {})
            for (key, _, _), em in zip(ICONS, ems):
                cur[key] = em
            db.put_setting("icons", cur)
        _no_custom.clear()
        db.set_pending(user.id, None, None)
        return await msg.reply_text("✅ Default saved — all groups without their own use it now. /defaults")
    if not await is_admin(ctx.bot, chat_id, user.id):
        db.set_pending(user.id, None, None)
        return await msg.reply_text("You're no longer an admin of that group.")
    text = (msg.text or "").strip()
    if step == "tok":
        token = text.lower().split("/")[-1].strip()
        meta = await near.metadata(token)
        if not meta:
            return await msg.reply_text("❌ Not a NEAR token contract (no ft_metadata). Try again or /cancel.")
        db.set(chat_id, token=token, symbol=str(meta.get("symbol") or "")[:16], decimals=int(meta["decimals"]))
        refresh_feed()
    elif step == "emo":
        ems = parse_emojis(msg)
        if not ems:
            return await msg.reply_text("Send at least one emoji.")
        db.set(chat_id, emojis=ems)
        _no_custom.discard(chat_id)
    elif step == "ico":
        ems = parse_emojis(msg)
        if not ems:
            return await msg.reply_text("Send at least one emoji.")
        cur = dict(db.group(chat_id).get("icons") or {})
        for (key, _, _), em in zip(ICONS, ems):
            cur[key] = em
        db.set(chat_id, icons=cur)
        _no_custom.discard(chat_id)
    elif step == "med":
        if msg.animation:
            db.set(chat_id, media_type="animation", media_id=msg.animation.file_id)
        elif msg.video:
            db.set(chat_id, media_type="video", media_id=msg.video.file_id)
        elif msg.photo:
            db.set(chat_id, media_type="photo", media_id=msg.photo[-1].file_id)
        else:
            return await msg.reply_text("Send a GIF, video or photo.")
    elif step == "lnk":
        m = re.match(r"^(?:https?://)?(?:t\.me|telegram\.me)/(\S+)$|^@([A-Za-z0-9_]{4,})$", text)
        if not m:
            return await msg.reply_text("Send a t.me link or @username.")
        db.set(chat_id, chat_link=f"https://t.me/{m.group(1) or m.group(2)}")
    elif step in ("min", "step", "max"):
        try:
            v = float(text.replace("$", "").replace(",", "."))
        except ValueError:
            return await msg.reply_text("Send a number.")
        if step == "min":
            db.set(chat_id, min_usd=max(0.0, v))
        elif step == "step":
            db.set(chat_id, step_usd=max(0.01, v))
        else:
            db.set(chat_id, max_emojis=int(min(60, max(1, v))))
    db.set_pending(user.id, None, None)
    await msg.reply_text("✅ Saved")
    await show_menu(msg, db.group(chat_id))


DEFAULT_STEPS = {"demo": "😀 Send the default emojis for the buy row (premium OK) — used by every group "
                         "that didn't set its own.",
                 "dico": None}


async def defaults(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Owner: default premium emojis for all groups."""
    if update.effective_user.id not in ADMIN_IDS:
        return
    b = lambda t, a: InlineKeyboardButton(t, callback_data=f"d:{a}")
    cur_e = db.get_setting("emojis") or DEFAULT_EMOJI
    em = "".join(f'<tg-emoji emoji-id="{c}">{html.escape(e)}</tg-emoji>' if c else html.escape(e) for e, c in cur_e)
    ic = "".join(icon({}, k, True) for k, _, _ in ICONS)
    await update.message.reply_text(
        f"🌐 <b>Defaults for all groups</b>\n\n😀 Buy row: {em}\n🎨 Icons: {ic}\n\n"
        "Groups with their own emojis/icons keep theirs.", parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([[b("😀 Buy row", "demo"), b("🎨 Icons", "dico")],
                                           [b("♻️ Reset defaults", "reset")]]))


async def on_defaults_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if q.from_user.id not in ADMIN_IDS:
        return await q.answer()
    await q.answer()
    act = q.data[2:]
    if act == "reset":
        db.put_setting("emojis", None)
        db.put_setting("icons", {})
        return await q.message.reply_text("♻️ Defaults reset to plain emojis.")
    db.set_pending(q.from_user.id, 0, act)
    await q.message.reply_text((DEFAULT_STEPS[act] or PROMPTS["ico"]) + "\n\n/cancel to stop",
                               parse_mode=ParseMode.HTML)


async def status(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return
    rows = db.all()
    lines = [f"Feed: {feed.state if feed else '-'} · buys pushed: {feed.pushed if feed else 0}",
             f"Groups: {len(rows)} (active {sum(r['active'] for r in rows)})", ""]
    lines += [f"{'🟢' if r['active'] else '⏸'} {r['title']} — {r['symbol']} · {r['posted']} posts" for r in rows[:50]]
    await update.message.reply_text("\n".join(lines))


async def post_init(app: Application):
    global feed
    bot_ref["bot"] = app.bot
    feed = BuyFeed(lambda: {g["token"] for g in db.active()}, on_buys)
    app.create_task(feed.run())


def main():
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("setup", group_setup, filters=filters.ChatType.GROUPS))
    app.add_handler(CommandHandler("cancel", cancel, filters=filters.ChatType.PRIVATE))
    app.add_handler(CommandHandler("status", status, filters=filters.ChatType.PRIVATE))
    app.add_handler(CommandHandler("defaults", defaults, filters=filters.ChatType.PRIVATE))
    app.add_handler(CallbackQueryHandler(on_defaults_button, pattern=r"^d:"))
    app.add_handler(CallbackQueryHandler(on_button, pattern=r"^m:"))
    app.add_handler(ChatMemberHandler(member_update, ChatMemberHandler.MY_CHAT_MEMBER))
    app.add_handler(MessageHandler(filters.ChatType.PRIVATE & ~filters.COMMAND, on_private))
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
