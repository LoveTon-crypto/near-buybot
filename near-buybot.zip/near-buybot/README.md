# ND Buybot — NEAR buy alerts for Telegram groups

Posts every buy of a NEAR token into a group: premium-emoji row (more emojis = bigger buy), amount in NEAR and USD,
tokens bought, price, MC, liquidity, holders, buyer (🆕 New holder), Chart / TX / Memepad links, your media
(GIF / video / photo) and quick-buy buttons for **Bettear** (with referral) and **NDbot**, plus the token chat link.

Buys come live from the Intear trade stream (`wss://api.intea.rs/ws`, `trades.subscribe`, side=buy) — one
connection for all tracked tokens; prices/MC/LP from Intear, DexScreener as fallback.

## Setup in a group
1. Add the bot to the group, make it admin.
2. Type `/setup` in the group → **⚙️ Configure in DM**.
3. In DM set: 🪙 token contract · 😀 emojis (premium OK) · 🖼 media · 💬 chat link · 💵 min buy · 📏 $ per emoji.
4. **🧪 Test post**, then **▶️ Start**.

`/status` (DM, ADMIN_IDS only) — feed state and all groups.

## Server
```bash
cd /root && git clone https://github.com/LoveTon-crypto/near-buybot && cd near-buybot
cp .env.example .env && nano .env      # BOT_TOKEN, ADMIN_IDS
bash deploy.sh                         # later updates: buybot-update
journalctl -u near-buybot -f           # logs
```

Note: Telegram only lets bots send **premium (custom) emojis** if the bot has a username bought on Fragment.
Without it the bot automatically falls back to the plain version of each emoji.
